using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Net;
using MySql.Data.MySqlClient;
using System.Web.Script.Serialization;
using Newtonsoft.Json.Linq;
//using RunIt.com.pixxsports.www;

namespace RunIt
{
    public struct GameCheckRecord
    {
        public bool Inserted;
        public Int32 TotalGames;
        public Int32 TotalWins;
        public Int32 TotalLosses;
        public Int32 TotalGames_after;
        public Int32 TotalWins_after;
        public Int32 TotalLosses_after;
    }

    public class Game
    {
        public string id { get; set; }
        public string gs { get; set; }
        public string ts { get; set; }
        public string tsc { get; set; }
        public string bs { get; set; }
        public string bsc { get; set; }
        public string atn { get; set; }
        public string atv { get; set; }
        public string ats { get; set; }
        public string atc { get; set; }
        public string htn { get; set; }
        public string htv { get; set; }
        public string hts { get; set; }
        public string htc { get; set; }
        public bool pl { get; set; }
        public bool rl { get; set; }
        public bool vl { get; set; }
        public bool gcl { get; set; }
        public bool gcll { get; set; }
        public string ustv { get; set; }
        public string catv { get; set; }
    }

    public class RootObject
    {
        public int startIndex { get; set; }
        public int refreshInterval { get; set; }
        public List<Game> games { get; set; }
    }
    public class GameObject
    {
        public string gameId { get; set; }
        public string gameTime { get; set; }
        public string gameDate { get; set; }
        public string homeTeam { get; set; }
        public string visitorTeam { get; set; }
        public string homeScore { get; set; }
        public string visitorScore { get; set; }
    }
    class Program
    {


        static void Main(string[] args)
        {

            string CompleteGameSourceID = "";
            JObject jObj = new JObject();
            RootObject oList2 = new RootObject();
            com.pixxsports.www.PixxGet ws = new com.pixxsports.www.PixxGet();
            //ws.Url = "http://localhost:61613/services/PixxGet.asmx";

            com.pixxsports.www.GameCheckRecord[] oResults;
            GameObject gObj = new GameObject();
            int SportID = (args.Length == 0 ? 1 : Convert.ToInt32(args[0]));
            //SportID = 2;
            string SportAbbreviation = "";



        try

        {
                SportAbbreviation = GetSportAbbreviation(SportID);

                string requestURL = getRequestURL(SportAbbreviation);
                //---------------------------------------------------
                // This is the web request regardless of the
                // sport
                //--------------------------------------------------
                string strOutput = makeTheRequest(requestURL);
                string sEmail = "";
                bool bGamesComplete = false;

                //string strGameDay = "";
                JArray jArr = new JArray();

                if (SportAbbreviation == "NFL")
                {
                    jObj = JObject.Parse(strOutput);


                    jArr = (JArray)jObj["gameScores"];

                    for (int i = 0; i < jArr.Count; i++)
                    {
                        bool bIgnore = false;
                        gObj.gameDate = convertToPixxGameDateNFL(jArr[i]["gameSchedule"]["gameDate"].ToString());

                        //if (SportID == 2 && gObj.gameDate.Trim() == "4/13")
                        //{
                        //    bIgnore = true;
                        //}

                        if (bIgnore == false)
                        {
                            // convert to GameObject                        
                            gObj.gameTime = convertTimeNFL(jArr, i);

                            gObj.gameId = jArr[i]["gameSchedule"]["gameId"].ToString();
                            gObj.homeTeam = jArr[i]["gameSchedule"]["homeTeam"]["abbr"].ToString();
                            gObj.homeScore = jArr[i]["score"]["homeTeamScore"]["pointTotal"].ToString();
                            gObj.visitorTeam = jArr[i]["gameSchedule"]["visitorTeam"]["abbr"].ToString();
                            gObj.visitorScore = jArr[i]["score"]["visitorTeamScore"]["pointTotal"].ToString();

                            oResults = ws.InsertGame(gObj.gameId,
                                                                gObj.gameTime,
                                                                gObj.gameDate,
                                                                gObj.homeTeam,
                                                                gObj.visitorTeam,
                                                                gObj.homeScore,
                                                                gObj.visitorScore,
                                                                SportID.ToString());

                            string tEmail = "";
                            bGamesComplete = GamesCompleteProcessing(oResults, out tEmail, gObj, SportID, ws);
                            sEmail = sEmail + tEmail;
                        }


                    }

                }



                if (SportAbbreviation == "NBA")
                {
                    jObj = JObject.Parse(strOutput);


                    jArr = (JArray)jObj["games"];

                    for (int i = 0; i < jArr.Count; i++)
                    {
                        bool bIgnore = false;
                        gObj.gameDate = convertToPixxGameDate(jArr[i]["startDateEastern"].ToString());

                        //if (SportID == 2 && gObj.gameDate.Trim() == "4/13")
                        //{
                        //    bIgnore = true;
                        //}

                        if (bIgnore == false)
                        {
                            // convert to GameObject                        
                            gObj.gameTime = convertTimeNBA(jArr, i);

                            gObj.gameId = jArr[i]["gameId"].ToString();
                            gObj.homeTeam = jArr[i]["hTeam"]["triCode"].ToString();
                            gObj.homeScore = jArr[i]["hTeam"]["score"].ToString();
                            gObj.visitorTeam = jArr[i]["vTeam"]["triCode"].ToString();
                            gObj.visitorScore = jArr[i]["vTeam"]["score"].ToString();

                            oResults = ws.InsertGame(gObj.gameId,
                                                                gObj.gameTime,
                                                                gObj.gameDate,
                                                                gObj.homeTeam,
                                                                gObj.visitorTeam,
                                                                gObj.homeScore,
                                                                gObj.visitorScore,
                                                                SportID.ToString());

                            string tEmail = "";
                            bGamesComplete = GamesCompleteProcessing(oResults, out tEmail, gObj, SportID, ws);
                            sEmail = sEmail + tEmail;
                        }


                    }

                }

                if (SportAbbreviation == "NHL")
                {
                    strOutput = strOutput.Replace("loadScoreboard(", "").Replace(")", "");
                    JavaScriptSerializer js = new JavaScriptSerializer();
                    oList2 = js.Deserialize<RootObject>(strOutput);

                    for (int i = 0; i < oList2.games.Count; i++)
                    {


                        // So this is playoff / end of season logic
                        // will revisit
                        bool bIgnore = false;
                        gObj.gameDate = convertDateNHL(oList2.games[i].ts);
                        
                        //if (SportID == 2 && gObj.gameDate.Trim() == "4/13")
                        //{
                        //    bIgnore = true;
                        //}

                        if (bIgnore == false)
                        {


                            gObj.gameTime = oList2.games[i].bs;
                            gObj.gameDate = oList2.games[i].ts;
                            try
                            {
                                //DateTime dConvert = new DateTime();
                                if (gObj.gameTime.Contains("AM")==true || gObj.gameTime.Contains("PM")==true)
                                {
                                    bool bAM = false;
                                    if (gObj.gameTime.Contains("PM") == true)
                                    {
                                        bAM = false;
                                    }

                                    var timeArr = gObj.gameTime.Split(':');
                                    if (Convert.ToInt32(timeArr[0]) != 12)
                                    {
                                        gObj.gameTime = gObj.gameTime.Replace(" PM", "").Replace(" AM", "");
                                        if (bAM == false)
                                        {
                                            var adjHours = Convert.ToInt32(timeArr[0]) + 12;
                                            adjHours = adjHours + 3; // east coast
                                            if (adjHours > 12)
                                            {
                                                bAM = false;
                                                adjHours = adjHours - 12;
                                            }
                                            else
                                            {
                                                bAM = true;
                                            }
                                            gObj.gameTime = "0" + adjHours.ToString() + ":" + timeArr[1].Replace(" PM", "").Replace(" AM", "") + " " + (bAM == true ? "AM" : "PM");
                                        }
                                    }
                                }

                                //gObj.gameTime = DateTime.AddHours(new DateTime(gObj.gameTime));
                            }
                            catch (Exception ext)
                            {
                                gObj.gameTime = oList2.games[i].bs;
                            }
                            gObj.gameId = oList2.games[i].id;
                            gObj.homeTeam = oList2.games[i].htn;
                            gObj.homeScore = oList2.games[i].hts;
                            gObj.visitorTeam = oList2.games[i].atn;
                            gObj.visitorScore = oList2.games[i].ats;

                            oResults = ws.InsertGame(           gObj.gameId,
                                                                gObj.gameTime,
                                                                gObj.gameDate,
                                                                gObj.homeTeam,
                                                                gObj.visitorTeam,
                                                                gObj.homeScore,
                                                                gObj.visitorScore,
                                                                SportID.ToString()
                                                        );
                            string tEmail = "";
                            bGamesComplete = GamesCompleteProcessing(oResults, out tEmail, gObj, SportID, ws);
                            sEmail = sEmail + tEmail;

                        }
                    }

                }

                // Update Standings
                if (bGamesComplete==true)
                {
                    // TO DO: need this to use NBA, NHL
                    switch (SportAbbreviation)
                    {
                        case "NHL":
                            //Bulk
                            UpdateStandings(SportID);
                            break;
                        case "NBA":
                            for (var i=0; i < jArr.Count; i++)
                            {
                                UpdateRecord(jArr[i]["hTeam"]["triCode"].ToString(), SportID.ToString(), jArr[i]["hTeam"]["win"].ToString(), jArr[i]["hTeam"]["loss"].ToString(), "0");
                                UpdateRecord(jArr[i]["vTeam"]["triCode"].ToString(), SportID.ToString(), jArr[i]["vTeam"]["win"].ToString(), jArr[i]["vTeam"]["loss"].ToString(), "0");
                            }
                            break;
                        case "NFL":
                            //Bulk
                            UpdateStandings(SportID);
                            break;

                    }


                }
                //Messaging starts here...
                string sEmailMessage = "";
                if (sEmail.Length > 0)
                {
                    var closeEmail = "</div></div></div>";
                    var openEmail = "<div><div style='padding:10px 10px 10px 10px; width:320px;margin: 0 auto;border:1px silver solid;border-radius:25px'><div style='margin:0 auto;text-align:center'><img src='http://www.pixxsports.com/img/header.png' width='240' /><br><div style='margin:0 auto;width:240px;font-size:16px;text-align:center'>";

                    sEmailMessage = "PIXX " + SportAbbreviation +" Games are up. Go PIXX some winners! www.pixxsports.com|" + openEmail +"<p>Hey [NAME]<br />&nbsp;<br />We have added new " + SportAbbreviation + " games to the system.</p><table border='0' cellpadding='3' cellspacing='3' style='padding-top:10px;margin:0 auto;min-width:240px'>";
                    sEmailMessage = sEmailMessage + sEmail;
                    sEmailMessage = sEmailMessage + "</table><p><br/>Be sure to make your PIXX at http://www.pixxsports.com or by using our app!</p>" + closeEmail;

                    ws.SendMassNotification("New Games", sEmailMessage, false, "", "", SportID.ToString());

                }
            }


            catch (Exception ex)
            {

            }

        }



        static string makeTheRequest(string requestURL)
        {
            string strOutput = "";

            HttpWebRequest request = WebRequest.Create(requestURL) as HttpWebRequest;
            //request.Method = "POST";
            request.KeepAlive = false;
            HttpWebResponse response = request.GetResponse() as HttpWebResponse;

            using (Stream stream = response.GetResponseStream())
            {
                StreamReader reader = new StreamReader(stream, Encoding.UTF8);
                strOutput = reader.ReadToEnd();
            }

            return strOutput;
        }

        static bool GamesCompleteProcessing(com.pixxsports.www.GameCheckRecord[] oResults, out string sEmail, GameObject gObj, int SportID, com.pixxsports.www.PixxGet ws)
        {
            //ws.SendMassNotification("Games Complete", "", false, "", "2017-11-20", SportID.ToString());
            string tempEmail = "";
            sEmail = tempEmail;
            bool bGamesComplete = false;

            if (oResults.Length > 0)
            {
                if (oResults[0].Inserted == true)
                {
                    tempEmail = tempEmail + "<tr><td colspan='2'><hr></td></tr>";
                    tempEmail = tempEmail + "<tr><td>" + gObj.gameDate + " @ ";
                    tempEmail = tempEmail + gObj.gameTime + "</td>";
                    tempEmail = tempEmail + "<td><table><tr><td>" + gObj.visitorTeam + "</td></tr>";
                    tempEmail = tempEmail + "<tr><td>@ " + gObj.homeTeam + "</td></tr></table>";
                    tempEmail = tempEmail + "</td>";
                    tempEmail = tempEmail + "</tr>";
                }
                sEmail = tempEmail;

                // Games Complete
                if (oResults[0].TotalGames != (oResults[0].TotalWins + oResults[0].TotalLosses))
                {
                    if (oResults[0].TotalGames_after == (oResults[0].TotalWins_after + oResults[0].TotalLosses_after))
                    {
                        // Set Game ID
                        //CompleteGameSourceID = gObj.gameId;
                        // Generate Points
                        ws.GeneratePoints(gObj.gameDate, SportID);
                        // if this is a game day
                        if (gObj.gameDate.Length > 0)
                        {
                            // Clean up Game Day

                            string sDate = GetMassNotificationDate(SportID, gObj.gameDate);


                            // Send Mass Notification
                            ws.SendMassNotification("Games Complete", "", false, "", sDate, SportID.ToString());
                            bGamesComplete = true;


                        }
                    }
                }

            }
            return bGamesComplete;
        }

        static void UpdateRecord(string sTeam, string sSport, string sWin, string sLoss, string sTie)
        {
            string sConn = "server=my04.winhost.com;database=mysql_97179_pixx;uid=pixx;pwd=password";

            MySqlConnection conn = new MySqlConnection(sConn);
            MySqlCommand cmd;

            try
            {
                conn.Open();

                cmd = conn.CreateCommand();

                cmd.CommandText = "usp_update_TeamRecord";
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                MySqlParameter parm = new MySqlParameter();
                cmd.Parameters.Add(new MySqlParameter("inTeam", sTeam));
                cmd.Parameters.Add(new MySqlParameter("inSportID", Convert.ToInt32(sSport)));
                cmd.Parameters.Add(new MySqlParameter("inWin", Convert.ToInt32(sWin)));
                cmd.Parameters.Add(new MySqlParameter("inLoss", Convert.ToInt32(sLoss)));
                cmd.Parameters.Add(new MySqlParameter("inTie", Convert.ToInt32(sTie)));

                MySqlDataReader reader;

                reader = cmd.ExecuteReader();

                reader.Close();
                conn.Close();
            }
            catch (Exception ex)
            {

            }

        }
        static void UpdateStandings(int SportID)
        {
            string sConn = "server=my04.winhost.com;database=mysql_97179_pixx;uid=pixx;pwd=password";

            MySqlConnection conn = new MySqlConnection(sConn);
            MySqlCommand cmd;

            conn.Open();

            cmd = conn.CreateCommand();
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            cmd.CommandText = "usp_update_standings";

            MySqlDataReader reader;

            reader = cmd.ExecuteReader();

            if (reader.HasRows == false)
            {
                reader.Close();
                conn.Close();
                // return;
            }
            else
            {
                reader.Close();
                conn.Close();
                // return;
            }
        }

        static string convertDateNHL(string inDate)
        {
            string strGameDay = inDate.Replace("SUNDAY", "");
            strGameDay = strGameDay.Replace("TODAY", "");
            strGameDay = strGameDay.Replace("MONDAY", "");
            strGameDay = strGameDay.Replace("TUESDAY", "");
            strGameDay = strGameDay.Replace("WEDNESDAY", "");
            strGameDay = strGameDay.Replace("THURSDAY", "");
            strGameDay = strGameDay.Replace("FRIDAY", "");
            strGameDay = strGameDay.Replace("SATURDAY", "");

            return strGameDay;
        }
        static string getRequestURL(string SportAbbr)
        {
            // need to change this to NHL, NBA, etc

            if (SportAbbr == "NHL")
            {
                return "http://live.nhle.com/GameData/RegularSeasonScoreboardv3.jsonp";
            }

            if (SportAbbr == "NBA")
            {
                // get current date
                DateTime luDate = new DateTime();
                luDate = DateTime.Now;
                //luDate = luDate.AddDays(4);


                string luMonth = "0" + luDate.Month.ToString();
                luMonth = luMonth.Substring(luMonth.Length - 2, 2);

                string luDay = "0" + luDate.Day.ToString();
                luDay = luDay.Substring(luDay.Length - 2, 2);

                return "https://data.nba.net/prod/v2/" + luDate.Year.ToString() + luMonth + luDay + "/scoreboard.json";
            }
            if (SportAbbr == "NFL")
            {
                return "https://feeds.nfl.com/feeds-rs/scores.json";
            }
            return "";
        }
        static string convertToPixxGameDateNFL(string strGameDay)
        {
            DateTime cDate = new DateTime();
            cDate = Convert.ToDateTime(strGameDay);
//            cDate = Convert.ToDateTime(strGameDay.Substring(5, 4) + "-" + strGameDay.Substring(0, 2) + "-" + strGameDay.Substring(3, 2));
            string cMon = "0" + cDate.Month.ToString();
            cMon = cMon.Substring(cMon.Length - 2, 2);
            string cDay = "0" + cDate.Day.ToString();
            cDay = cDay.Substring(cDay.Length - 2, 2);
            strGameDay = cMon + "/" + cDay;
            return strGameDay;
        }
        static string convertToPixxGameDate(string strGameDay)
        {
            DateTime cDate = new DateTime();
            cDate = Convert.ToDateTime(strGameDay.Substring(0, 4) + "-" + strGameDay.Substring(4, 2) + "-" + strGameDay.Substring(6, 2));
            string cMon = "0" + cDate.Month.ToString();
            cMon = cMon.Substring(cMon.Length - 2, 2);
            string cDay = "0" + cDate.Day.ToString();
            cDay = cDay.Substring(cDay.Length - 2, 2);
            strGameDay = cMon + "/" + cDay;
            return strGameDay;
        }
        static string convertTimeNFL(JArray jArr, int i)
        {
            string sTimeDisplay = "";
            sTimeDisplay = jArr[i]["score"]["time"].ToString();

            if (jArr[i]["score"]["phase"].ToString() == "PREGAME")
            {
                sTimeDisplay = jArr[i]["gameSchedule"]["gameTimeEastern"].ToString();
                sTimeDisplay = DateTime.Parse(sTimeDisplay).ToString(@"hh\:mm\ tt") + " (EST)";
            }
            else
            {
                sTimeDisplay = jArr[i]["score"]["time"].ToString() + " " + jArr[i]["score"]["phaseDescription"].ToString();
            }
            return sTimeDisplay;

        }
        static string convertTimeNBA(JArray jArr, int i)
        {


            string sTimeDisplay = "";

            if (jArr[i]["statusNum"].ToString() == "1")
            {
                sTimeDisplay = jArr[i]["startTimeEastern"].ToString();
            }
            else if (jArr[i]["statusNum"].ToString() == "2")
            {
                switch (jArr[i]["period"]["current"].ToString())
                {
                    case "1":
                        sTimeDisplay = "1st ";
                        break;
                    case "2":
                        sTimeDisplay = "2nd ";
                        break;
                    case "3":
                        sTimeDisplay = "3rd ";
                        break;
                    case "4":
                        sTimeDisplay = "4th ";
                        break;
                    default:
                        sTimeDisplay = "OT ";
                        break;
                }
                sTimeDisplay = sTimeDisplay + jArr[i]["clock"].ToString();

                if (jArr[i]["period"]["isHalftime"].ToString() == "true")
                {
                    sTimeDisplay = "Halftime";
                }
                else if (jArr[i]["period"]["isEndOfPeriod"].ToString() == "true")
                {
                    switch (jArr[i]["period"]["current"].ToString())
                    {
                        case "1":
                            sTimeDisplay = "End of 1st ";
                            break;
                        case "2":
                            sTimeDisplay = "End of 2nd ";
                            break;
                        case "3":
                            sTimeDisplay = "End of 3rd ";
                            break;
                        case "4":
                            sTimeDisplay = "End of 4th ";
                            break;
                    }
                }
            }
            else
            {
                sTimeDisplay = sTimeDisplay + "FINAL";
            }
            return sTimeDisplay;
        }
        static string GetMassNotificationDate(int SportID, string inDate)
        {
            string strGameDayCleaned = inDate.Replace(" ", "");
            //-----------------------------------
            // Dates needed for Mass Notification
            //------------------------------------
            DateTime d;

            d = Convert.ToDateTime(strGameDayCleaned + "/" + DateTime.Now.Year.ToString());
            string sMon = "0" + d.Month.ToString();
            sMon = sMon.Substring(sMon.Length - 2, 2);
            string sDay = "0" + d.Day.ToString();
            sDay = sDay.Substring(sDay.Length - 2, 2);
            string sDate = d.Year.ToString() + "-" + sMon + "-" + sDay;

            return sDate;
        }
        static string GetSportAbbreviation(int SportID)
        {
            MySqlConnection conn = new MySqlConnection();
            MySqlDataReader reader = null;
            string strRet = "";

            try
            {

                string sConn = "server=my04.winhost.com;database=mysql_97179_pixx;uid=pixx;pwd=password";

                conn.ConnectionString = sConn;
                conn.Open();

                MySqlCommand cmd;
                cmd = conn.CreateCommand();
                cmd.CommandType = System.Data.CommandType.Text;

                cmd.CommandText = "Select SportAbbreviation FROM Sport WHERE DeleteDate IS NULL AND SportID=" + SportID.ToString();

                reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    strRet = reader["SportAbbreviation"].ToString();
                }

                return strRet;
            }

            catch (Exception ex)
            {
                //ErrorRtn(ex.ToString());
                return strRet;
            }

            finally
            {
                if (reader != null)
                {
                    reader.Close();
                }

                if (conn.State == System.Data.ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }
    }
}
